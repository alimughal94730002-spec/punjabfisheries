<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" dir="{{ app()->getLocale() === 'ur' ? 'rtl' : 'ltr' }}">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' 'unsafe-eval' 'unsafe-inline' https://fonts.googleapis.com https://fonts.gstatic.com https://cdn.plyr.io; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdn.plyr.io; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https:; connect-src 'self'; media-src 'self' https:; object-src 'none'; base-uri 'self'; form-action 'self';" />
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>@yield('title', 'Department of Fisheries - Punjab')</title>
  <link rel="shortcut icon" href="{{ asset('assets/images/fav.png') }}" type="image/x-icon" />
  <link rel="preconnect" href="https://fonts.googleapis.com/" />
  <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="{{ asset('assets/css/swiper.min.css') }}" />
  <link rel="stylesheet" href="{{ asset('assets/css/glightbox.css') }}" />
  <link rel="stylesheet" href="{{ asset('assets/css/styles.css') }}" />
  <style>
    /* Urdu text rendering fixes for frontend only */
    [lang="ur"], .urdu-text {
        font-family: "Noto Sans Arabic", "Segoe UI", "Tahoma", "Arial", sans-serif;
        direction: rtl;
        text-align: right;
        word-spacing: normal;
        letter-spacing: normal;
        line-height: 1.6;
    }
    
    /* Fix for Urdu text in headings */
    h1[lang="ur"], h2[lang="ur"], h3[lang="ur"], h4[lang="ur"], h5[lang="ur"], h6[lang="ur"],
    h1.urdu-text, h2.urdu-text, h3.urdu-text, h4.urdu-text, h5.urdu-text, h6.urdu-text {
        font-family: "Noto Sans Arabic", "Segoe UI", "Tahoma", "Arial", sans-serif;
        direction: rtl;
        text-align: right;
        word-spacing: normal;
        letter-spacing: normal;
        line-height: 1.4;
        unicode-bidi: bidi-override;
    }
  </style>
  @stack('styles')
  <script defer src="{{ asset('assets/js/app.min.js') }}"></script>
  @stack('head')
</head>
<body>
  {{-- Loader --}}
  <div class="screen_loader fixed inset-0 z-[101] grid place-content-center bg-neutral-0">
    <div class="w-10 h-10 border-4 border-t-primary-400 border-neutral-40 rounded-full animate-spin"></div>
  </div>

  {{-- Conditional Header - Different header for homepage vs other pages --}}
  @if(request()->is('/'))
    {{-- Homepage Header (from index.blade.php) --}}
    @include('frontend.layouts.homepage-header')
  @else
    {{-- Regular Header for other pages --}}
    @include('frontend.layouts.header')
  @endif

  {{-- Support both @extends and component approaches --}}
  @hasSection('content')
    @yield('content')
  @else
    {{ $slot }}
  @endif

  @include('frontend.layouts.footer')

  @stack('scripts')
</body>
</html>

